from colorboy.styles import *
from colorboy.colors import *
from colorboy.bg_colors import *